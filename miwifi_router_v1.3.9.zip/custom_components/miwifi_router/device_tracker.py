"""Device tracker platform for MiWiFi Router.

Provides device online/offline detection and per-device speed monitoring.
Each connected device appears as a device_tracker entity with speed attributes.

Uses TrackerEntity with overridden state property to return "home"/"not_home"
based on the router's is_connected status. TrackerEntity's default state
property only looks at GPS coordinates and ignores is_connected, which would
cause the state to show "unknown". We override it to fix this.

Naming: _attr_has_entity_name = False because each device_tracker represents
an independent network device, NOT a sub-feature of the router. The entity
name should be the device's own name (from router API devname) without
the router model prefix.
"""

from __future__ import annotations

import logging
from typing import Any

from homeassistant.components.device_tracker import (
    SourceType,
    TrackerEntity,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import STATE_HOME, STATE_NOT_HOME
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import MiWiFiCoordinator

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up MiWiFi Router device trackers from a config entry."""
    coordinator: MiWiFiCoordinator = hass.data[DOMAIN][entry.entry_id]
    api = coordinator.api

    # Dynamic entity approach: a tracker manager adds trackers as devices appear
    tracker_manager = MiWiFiTrackerManager(
        hass, coordinator, async_add_entities, api.model, api.firmware
    )

    # Register a listener to update device trackers when coordinator data changes
    entry.async_on_unload(
        coordinator.async_add_listener(tracker_manager.update_devices)
    )

    # Initial setup with current data
    tracker_manager.update_devices()


class MiWiFiTrackerManager:
    """Manages dynamic device tracker entities.

    New devices are added as they appear; offline devices stay in the registry
    as 'not_home' so that automations can still trigger on state changes.
    """

    def __init__(
        self,
        hass: HomeAssistant,
        coordinator: MiWiFiCoordinator,
        async_add_entities: AddEntitiesCallback,
        model: str,
        firmware: str,
    ) -> None:
        self._hass = hass
        self._coordinator = coordinator
        self._async_add_entities = async_add_entities
        self._model = model
        self._firmware = firmware
        self._known_devices: dict[str, MiWiFiDeviceTracker] = {}

    def update_devices(self) -> None:
        """Update device trackers based on latest coordinator data."""
        data = self._coordinator.router_data
        devices = data.devices

        new_entities: list[MiWiFiDeviceTracker] = []

        for mac, dev_data in devices.items():
            if mac in self._known_devices:
                # Update existing tracker data (only if entity is fully registered)
                self._known_devices[mac].set_dev_data(dev_data)
            else:
                # Create new tracker for newly seen device
                tracker = MiWiFiDeviceTracker(
                    coordinator=self._coordinator,
                    mac=mac,
                    dev_data=dev_data,
                    model=self._model,
                    firmware=self._firmware,
                )
                self._known_devices[mac] = tracker
                new_entities.append(tracker)

        if new_entities:
            self._async_add_entities(new_entities, update_before_add=True)

        # Mark devices not in current poll as offline
        current_macs = set(devices.keys())
        for mac, tracker in self._known_devices.items():
            if mac not in current_macs:
                tracker.set_dev_data({**tracker._dev_data, "online": 0})


class MiWiFiDeviceTracker(CoordinatorEntity[MiWiFiCoordinator], TrackerEntity):
    """Representation of a network device tracked by MiWiFi Router.

    Uses TrackerEntity with overridden state property.
    TrackerEntity's default state() only checks GPS coordinates and returns None
    when there are none, causing "unknown" state. We override state to return
    "home" / "not_home" based on is_connected.
    """

    _attr_has_entity_name = False

    def __init__(
        self,
        coordinator: MiWiFiCoordinator,
        mac: str,
        dev_data: dict[str, Any],
        model: str,
        firmware: str,
    ) -> None:
        """Initialize the device tracker."""
        super().__init__(coordinator)
        self._mac = mac
        self._dev_data = dev_data
        self._model = model
        self._firmware = firmware
        self._is_connected: bool = False

        # Unique ID based on router host + device MAC
        self._attr_unique_id = f"{coordinator.api._host}_device_{mac}"

        # Friendly name - use the device's own name from the router API.
        # Priority: name (from devname) > hostname > MAC fallback
        # With _attr_has_entity_name = False, this becomes the full display
        # name without the router model prefix.
        name = dev_data.get("name", "")
        if not name or name.upper() == mac.upper():
            name = dev_data.get("hostname", "")
        if not name or name.upper() == mac.upper():
            name = f"Device {mac}"
        self._attr_name = name

        # Initial connection state
        self._update_connection_state(dev_data)

    def _update_connection_state(self, dev_data: dict[str, Any]) -> None:
        """Update the connection state from device data."""
        online_val = dev_data.get("online", 0)
        self._is_connected = int(online_val) > 0 if online_val else False

    @property
    def state(self) -> str:
        """Return the state of the device.

        Override TrackerEntity's default state property which only checks
        GPS coordinates (returns None for non-GPS trackers → "unknown").
        We use is_connected instead to return "home" / "not_home".
        """
        if self._is_connected:
            return STATE_HOME
        return STATE_NOT_HOME

    @property
    def source_type(self) -> SourceType:
        """Return the source type of the device tracker."""
        return SourceType.ROUTER

    @callback
    def _handle_coordinator_update(self) -> None:
        """Handle coordinator update - update device data from merged data."""
        devices = self.coordinator.router_data.devices
        if self._mac in devices:
            self._update_from_data(devices[self._mac])
        self.async_write_ha_state()

    def _update_from_data(self, dev_data: dict[str, Any]) -> None:
        """Update internal state from device data dict."""
        self._dev_data = dev_data
        self._update_connection_state(dev_data)

        # Update name if we got a more descriptive one
        # Priority: name (from devname) > hostname — same as __init__
        name = dev_data.get("name", "")
        hostname = dev_data.get("hostname", "")
        preferred_name = name if name and name.upper() != self._mac.upper() else hostname
        if preferred_name and preferred_name.upper() != self._mac.upper() and preferred_name.strip():
            self._attr_name = preferred_name

    def set_dev_data(self, dev_data: dict[str, Any]) -> None:
        """Set device data. Only writes HA state if entity is fully registered."""
        self._update_from_data(dev_data)
        # Only write state if entity has been fully added to HA
        if self.hass is not None and self.entity_id is not None:
            self.async_write_ha_state()

    @property
    def device_info(self) -> dict[str, Any]:
        """Return device info - link all trackers to the router device."""
        return {
            "identifiers": {(DOMAIN, self.coordinator.api._host)},
            "name": self._model or "MiWiFi Router",
            "manufacturer": "Xiaomi",
            "model": self._model,
            "sw_version": self._firmware,
        }

    @property
    def ip_address(self) -> str | None:
        """Return the IP address of the device."""
        return self._dev_data.get("ip") or None

    @property
    def mac_address(self) -> str:
        """Return the MAC address of the device."""
        return self._mac

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return per-device speed and detail attributes."""
        upspeed = int(self._dev_data.get("upspeed", 0))
        downspeed = int(self._dev_data.get("downspeed", 0))
        upload = int(self._dev_data.get("upload", 0))
        download = int(self._dev_data.get("download", 0))
        online_seconds = int(self._dev_data.get("online", 0))

        attrs: dict[str, Any] = {
            "mac": self._mac,
            "ip": self._dev_data.get("ip", ""),
            # Per-device speed (raw bytes/sec)
            "upload_speed": upspeed,
            "upload_speed_human": self._format_speed(upspeed),
            "download_speed": downspeed,
            "download_speed_human": self._format_speed(downspeed),
            # Per-device cumulative totals
            "upload_total": upload,
            "upload_total_human": self._format_bytes(upload),
            "download_total": download,
            "download_total_human": self._format_bytes(download),
            # Peak speeds
            "max_upload_speed": int(self._dev_data.get("maxuploadspeed", 0)),
            "max_download_speed": int(self._dev_data.get("maxdownloadspeed", 0)),
            # Online duration in seconds
            "online_seconds": online_seconds,
            "is_ap": bool(int(self._dev_data.get("isap", 0))),
        }

        # Optional fields from device_list endpoint
        if "signal" in self._dev_data and self._dev_data["signal"]:
            attrs["signal"] = int(self._dev_data["signal"])
        if "channel" in self._dev_data and self._dev_data["channel"]:
            attrs["channel"] = self._dev_data["channel"]
        if "oui" in self._dev_data and self._dev_data["oui"]:
            attrs["oui"] = self._dev_data["oui"]
        if "hostname" in self._dev_data and self._dev_data["hostname"]:
            attrs["hostname"] = self._dev_data["hostname"]

        return attrs

    @staticmethod
    def _format_speed(speed_bytes: int) -> str:
        """Format speed for human readability."""
        if speed_bytes >= 1_000_000:
            return f"{speed_bytes / 1_000_000:.2f} MB/s"
        if speed_bytes >= 1_000:
            return f"{speed_bytes / 1_000:.2f} KB/s"
        return f"{speed_bytes} B/s"

    @staticmethod
    def _format_bytes(total_bytes: int) -> str:
        """Format bytes for human readability."""
        if total_bytes >= 1_000_000_000_000:
            return f"{total_bytes / 1_000_000_000_000:.2f} TB"
        if total_bytes >= 1_000_000_000:
            return f"{total_bytes / 1_000_000_000:.2f} GB"
        if total_bytes >= 1_000_000:
            return f"{total_bytes / 1_000_000:.2f} MB"
        if total_bytes >= 1_000:
            return f"{total_bytes / 1_000:.2f} KB"
        return f"{total_bytes} B"
